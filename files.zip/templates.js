/**
 * templates.js
 *
 * Pre-compiled contract templates.
 * Each template has:
 *   - abi:       the contract ABI
 *   - bytecode:  compiled bytecode (0x-prefixed)
 *   - getArgs(): returns constructor args array from form inputs
 *   - summary(): returns a human-readable object for the review panel
 *
 * HOW TO RECOMPILE:
 *   1. Open remix.ethereum.org
 *   2. Paste the Solidity source (comments below each template)
 *   3. Compile with Solidity 0.8.20, optimiser ON, 200 runs
 *   4. Copy bytecode from Compilation Details → Bytecode → object
 *   5. Replace the bytecode field below (prefix with 0x)
 */

// ─────────────────────────────────────────────────────────────────────────
//  ERC-20 TOKEN
//  Source: contracts/SimpleToken.sol
//
//  pragma solidity ^0.8.20;
//  contract SimpleToken {
//    string public name; string public symbol; uint8 public decimals;
//    uint256 public totalSupply;
//    mapping(address=>uint256) public balanceOf;
//    mapping(address=>mapping(address=>uint256)) public allowance;
//    event Transfer(address indexed from, address indexed to, uint256 value);
//    event Approval(address indexed owner, address indexed spender, uint256 value);
//    constructor(string memory _name,string memory _symbol,uint8 _decimals,uint256 _totalSupply) {
//      name=_name; symbol=_symbol; decimals=_decimals;
//      totalSupply=_totalSupply * 10**_decimals;
//      balanceOf[msg.sender]=totalSupply;
//      emit Transfer(address(0),msg.sender,totalSupply);
//    }
//    function transfer(address to,uint256 value) public returns(bool) {
//      require(balanceOf[msg.sender]>=value,"Insufficient balance");
//      balanceOf[msg.sender]-=value; balanceOf[to]+=value;
//      emit Transfer(msg.sender,to,value); return true;
//    }
//    function approve(address spender,uint256 value) public returns(bool) {
//      allowance[msg.sender][spender]=value;
//      emit Approval(msg.sender,spender,value); return true;
//    }
//    function transferFrom(address from,address to,uint256 value) public returns(bool) {
//      require(balanceOf[from]>=value,"Insufficient balance");
//      require(allowance[from][msg.sender]>=value,"Insufficient allowance");
//      balanceOf[from]-=value; balanceOf[to]+=value;
//      allowance[from][msg.sender]-=value;
//      emit Transfer(from,to,value); return true;
//    }
//  }
// ─────────────────────────────────────────────────────────────────────────
const TOKEN_TEMPLATE = {
  // ↓ Paste your compiled bytecode here after compiling the source above
  bytecode: "PASTE_TOKEN_BYTECODE_HERE",

  abi: [
    { "inputs": [
        { "internalType": "string",  "name": "_name",        "type": "string"  },
        { "internalType": "string",  "name": "_symbol",      "type": "string"  },
        { "internalType": "uint8",   "name": "_decimals",    "type": "uint8"   },
        { "internalType": "uint256", "name": "_totalSupply", "type": "uint256" }
      ],
      "stateMutability": "nonpayable", "type": "constructor"
    },
    { "anonymous": false, "inputs": [
        { "indexed": true, "name": "from",  "type": "address" },
        { "indexed": true, "name": "to",    "type": "address" },
        { "indexed": false,"name": "value", "type": "uint256" }
      ],
      "name": "Transfer", "type": "event"
    },
    { "anonymous": false, "inputs": [
        { "indexed": true, "name": "owner",   "type": "address" },
        { "indexed": true, "name": "spender", "type": "address" },
        { "indexed": false,"name": "value",   "type": "uint256" }
      ],
      "name": "Approval", "type": "event"
    },
    { "inputs": [{"name":"","type":"address"}], "name": "balanceOf",  "outputs": [{"type":"uint256"}], "stateMutability":"view","type":"function" },
    { "inputs": [],                             "name": "decimals",   "outputs": [{"type":"uint8"}],   "stateMutability":"view","type":"function" },
    { "inputs": [],                             "name": "name",       "outputs": [{"type":"string"}],  "stateMutability":"view","type":"function" },
    { "inputs": [],                             "name": "symbol",     "outputs": [{"type":"string"}],  "stateMutability":"view","type":"function" },
    { "inputs": [],                             "name": "totalSupply","outputs": [{"type":"uint256"}], "stateMutability":"view","type":"function" },
    { "inputs": [{"name":"to","type":"address"},{"name":"value","type":"uint256"}],
      "name": "transfer", "outputs": [{"type":"bool"}], "stateMutability":"nonpayable","type":"function" },
    { "inputs": [{"name":"spender","type":"address"},{"name":"value","type":"uint256"}],
      "name": "approve",  "outputs": [{"type":"bool"}], "stateMutability":"nonpayable","type":"function" },
    { "inputs": [{"name":"from","type":"address"},{"name":"to","type":"address"},{"name":"value","type":"uint256"}],
      "name": "transferFrom","outputs": [{"type":"bool"}],"stateMutability":"nonpayable","type":"function" },
    { "inputs": [{"name":"","type":"address"},{"name":"","type":"address"}],
      "name": "allowance","outputs": [{"type":"uint256"}],"stateMutability":"view","type":"function" }
  ],

  getArgs() {
    const name     = document.getElementById('token-name').value.trim();
    const symbol   = document.getElementById('token-symbol').value.trim();
    const decimals = parseInt(document.getElementById('token-decimals').value || '18');
    const supply   = document.getElementById('token-supply').value.trim();
    return [name, symbol, decimals, supply];
  },

  validate() {
    const errors = [];
    if (!document.getElementById('token-name').value.trim())   errors.push('Token name is required');
    if (!document.getElementById('token-symbol').value.trim()) errors.push('Token symbol is required');
    if (!document.getElementById('token-supply').value.trim()) errors.push('Total supply is required');
    return errors;
  },

  summary() {
    return {
      'Type':         'ERC-20 Token',
      'Name':         document.getElementById('token-name').value.trim() || '—',
      'Symbol':       document.getElementById('token-symbol').value.trim() || '—',
      'Decimals':     document.getElementById('token-decimals').value || '18',
      'Total Supply': Number(document.getElementById('token-supply').value || 0).toLocaleString(),
    };
  }
};


// ─────────────────────────────────────────────────────────────────────────
//  ERC-721 NFT
//  Source: contracts/SimpleNFT.sol
//
//  pragma solidity ^0.8.20;
//  import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
//  import "@openzeppelin/contracts/access/Ownable.sol";
//  contract SimpleNFT is ERC721, Ownable {
//    uint256 public maxSupply;
//    uint256 public totalMinted;
//    string private _baseTokenURI;
//    constructor(string memory name,string memory symbol,string memory baseURI,uint256 _maxSupply)
//      ERC721(name,symbol) Ownable(msg.sender) {
//        _baseTokenURI=baseURI; maxSupply=_maxSupply;
//    }
//    function mint(address to) external onlyOwner {
//      require(totalMinted<maxSupply,"Max supply reached");
//      _safeMint(to,++totalMinted);
//    }
//    function _baseURI() internal view override returns(string memory) { return _baseTokenURI; }
//  }
//
//  NOTE: Import OpenZeppelin in Remix via npm plugin or use flattened version.
// ─────────────────────────────────────────────────────────────────────────
const NFT_TEMPLATE = {
  // ↓ Paste your compiled bytecode here
  bytecode: "PASTE_NFT_BYTECODE_HERE",

  abi: [
    { "inputs": [
        { "internalType": "string",  "name": "name",       "type": "string"  },
        { "internalType": "string",  "name": "symbol",     "type": "string"  },
        { "internalType": "string",  "name": "baseURI",    "type": "string"  },
        { "internalType": "uint256", "name": "_maxSupply", "type": "uint256" }
      ],
      "stateMutability": "nonpayable", "type": "constructor"
    },
    { "inputs": [{"name":"to","type":"address"}],
      "name": "mint", "outputs": [], "stateMutability":"nonpayable","type":"function" },
    { "inputs": [], "name": "name",        "outputs": [{"type":"string"}],  "stateMutability":"view","type":"function" },
    { "inputs": [], "name": "symbol",      "outputs": [{"type":"string"}],  "stateMutability":"view","type":"function" },
    { "inputs": [], "name": "maxSupply",   "outputs": [{"type":"uint256"}], "stateMutability":"view","type":"function" },
    { "inputs": [], "name": "totalMinted", "outputs": [{"type":"uint256"}], "stateMutability":"view","type":"function" },
    { "inputs": [], "name": "owner",       "outputs": [{"type":"address"}], "stateMutability":"view","type":"function" },
    { "inputs": [{"name":"tokenId","type":"uint256"}],
      "name": "tokenURI","outputs": [{"type":"string"}],"stateMutability":"view","type":"function" }
  ],

  getArgs() {
    return [
      document.getElementById('nft-name').value.trim(),
      document.getElementById('nft-symbol').value.trim(),
      document.getElementById('nft-uri').value.trim(),
      document.getElementById('nft-supply').value.trim(),
    ];
  },

  validate() {
    const errors = [];
    if (!document.getElementById('nft-name').value.trim())   errors.push('Collection name is required');
    if (!document.getElementById('nft-symbol').value.trim()) errors.push('Symbol is required');
    if (!document.getElementById('nft-uri').value.trim())    errors.push('Metadata URI is required');
    if (!document.getElementById('nft-supply').value.trim()) errors.push('Max supply is required');
    return errors;
  },

  summary() {
    return {
      'Type':       'ERC-721 NFT Collection',
      'Name':       document.getElementById('nft-name').value.trim() || '—',
      'Symbol':     document.getElementById('nft-symbol').value.trim() || '—',
      'Base URI':   document.getElementById('nft-uri').value.trim() || '—',
      'Max Supply': Number(document.getElementById('nft-supply').value || 0).toLocaleString(),
    };
  }
};


// ─────────────────────────────────────────────────────────────────────────
//  SIMPLE STORAGE
//  Source: contracts/SimpleStorage.sol
//
//  pragma solidity ^0.8.20;
//  contract SimpleStorage {
//    uint256 private storedValue;
//    event ValueChanged(uint256 newValue);
//    constructor(uint256 initialValue) { storedValue = initialValue; }
//    function store(uint256 value) public { storedValue=value; emit ValueChanged(value); }
//    function retrieve() public view returns(uint256) { return storedValue; }
//  }
// ─────────────────────────────────────────────────────────────────────────
const STORAGE_TEMPLATE = {
  // ↓ Paste your compiled bytecode here
  bytecode: "PASTE_STORAGE_BYTECODE_HERE",

  abi: [
    { "inputs": [{"internalType":"uint256","name":"initialValue","type":"uint256"}],
      "stateMutability": "nonpayable", "type": "constructor"
    },
    { "anonymous": false, "inputs": [{"indexed":false,"name":"newValue","type":"uint256"}],
      "name": "ValueChanged", "type": "event" },
    { "inputs": [{"name":"value","type":"uint256"}],
      "name": "store",    "outputs": [], "stateMutability":"nonpayable","type":"function" },
    { "inputs": [],
      "name": "retrieve", "outputs": [{"type":"uint256"}],"stateMutability":"view","type":"function" }
  ],

  getArgs() {
    return [document.getElementById('storage-value').value || '0'];
  },

  validate() {
    return []; // no required fields
  },

  summary() {
    return {
      'Type':          'Simple Storage',
      'Initial Value': document.getElementById('storage-value').value || '0',
    };
  }
};


// ─────────────────────────────────────────────────────────────────────────
//  CUSTOM — user provides their own bytecode + ABI
// ─────────────────────────────────────────────────────────────────────────
const CUSTOM_TEMPLATE = {
  get bytecode() { return document.getElementById('custom-bytecode').value.trim(); },
  get abi()      { try { return JSON.parse(document.getElementById('custom-abi').value.trim()); } catch { return []; } },

  getArgs() {
    const args = [];
    document.querySelectorAll('.arg-row').forEach(row => {
      args.push(row.querySelector('.arg-val').value.trim());
    });
    return args;
  },

  validate() {
    const errors = [];
    const bc = document.getElementById('custom-bytecode').value.trim();
    if (!bc)                                              errors.push('Bytecode is required');
    else if (!/^0x[0-9a-fA-F]+$/.test(bc))               errors.push('Bytecode must be valid 0x-prefixed hex');
    const abiRaw = document.getElementById('custom-abi').value.trim();
    if (!abiRaw)                                          errors.push('ABI is required');
    else { try { JSON.parse(abiRaw); } catch { errors.push('ABI is not valid JSON'); } }
    return errors;
  },

  summary() {
    const bc = document.getElementById('custom-bytecode').value.trim();
    let fnCount = '—';
    try { fnCount = JSON.parse(document.getElementById('custom-abi').value).filter(x=>x.type==='function').length; } catch {}
    return {
      'Type':      'Custom Contract',
      'Bytecode':  bc ? Math.floor((bc.length-2)/2) + ' bytes' : '—',
      'Functions': fnCount,
    };
  }
};


// Export lookup
const TEMPLATES = {
  token:   TOKEN_TEMPLATE,
  nft:     NFT_TEMPLATE,
  storage: STORAGE_TEMPLATE,
  custom:  CUSTOM_TEMPLATE,
};
